<?php
    $server="localhost";
    $user="root";
    $pass="";
    $db="gamesdatabase";
    $conn=mysqli_connect($server,$user,$pass,$db);
?>